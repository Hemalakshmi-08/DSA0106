# BudgetBuddy

**BudgetBuddy – An Adaptive Student Expense and Savings Optimization System Using Object-Oriented C++**

A student budgeting web application built with C++17, cpp-httplib, SQLite, OpenSSL, HTML5 and CSS3. The UI uses the existing pink/lavender theme. The application is organized into four modules:

1. Adaptive Allowance & Expense Intelligence
2. Smart Spending Leakage & Expense Prioritization
3. Budget Rescue & Financial Risk Simulation
4. Goal-Based Savings Optimization

## Run locally on Windows

Install Visual Studio Community with Desktop development with C++, CMake, Git and vcpkg. Ensure the project's dependencies are installed from `vcpkg.json`.

Open a Visual Studio Developer Command Prompt and run:

```bat
cd /d "C:\path\to\BudgetBuddy"
set VCPKG_ROOT=C:\vcpkg
cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE=C:\vcpkg\scripts\buildsystems\vcpkg.cmake -DVCPKG_TARGET_TRIPLET=x64-windows
cmake --build build --config Release
.\build\Release\BudgetBuddy.exe
```

Open `http://127.0.0.1:8080` in your browser. Keep the terminal open while using the application. `START_BUDGETBUDDY.bat` launches the built executable and opens the browser.

## Existing database compatibility

The application stores data in `budgetbuddy.db` in the project working directory. Back up the database before upgrading. New schema objects are created with `CREATE TABLE IF NOT EXISTS`; the new expense regret field is added with a guarded `ALTER TABLE`. Existing records are retained.

## Smart Tools

Sign in and use **Smart Tools** in the navigation to access the detailed feature sections for all four modules: living-cost assumptions, allowance-day planning, daily wallet estimate, commitments, Quick Add, regret insights, subscriptions, Money Wrapped, shock simulation, wishlist lock, Broke Mode, goal split, round-ups, Friends Owe Me and achievement badges.

All cost references are user-entered assumptions. Forecasts are estimates from records, not bank data. Quick Add is a keyword parser, not AI. Goal auto-split is a recommendation and does not silently move money.

See `UPGRADE_NOTES.md` for the full change list and verification details. See `TESTING.md` for model-test guidance.
