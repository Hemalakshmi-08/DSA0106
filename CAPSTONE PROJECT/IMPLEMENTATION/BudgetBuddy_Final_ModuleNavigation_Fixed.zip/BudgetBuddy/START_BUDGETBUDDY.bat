@echo off
setlocal
cd /d "%~dp0"
title BudgetBuddy Server
if not exist "build\Release\BudgetBuddy.exe" (
  echo BudgetBuddy has not been built yet.
  echo Open this folder in Visual Studio and build the Release configuration first.
  pause
  exit /b 1
)
echo Starting BudgetBuddy. Keep this window open while using the website.
start "BudgetBuddy Browser" /b cmd /c "timeout /t 2 /nobreak ^>nul ^& start http://127.0.0.1:8080"
"build\Release\BudgetBuddy.exe"
echo.
echo BudgetBuddy server stopped. Check budgetbuddy-errors.log if a request failed.
pause
endlocal
