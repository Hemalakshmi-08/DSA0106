# BudgetBuddy – consolidated upgrade notes

This project keeps the existing C++17 + cpp-httplib + SQLite + OpenSSL stack and the existing pink/lavender stylesheet. Existing `budgetbuddy.db` files are upgraded in place: all new tables use `CREATE TABLE IF NOT EXISTS`; the `expenses.regret` field is added through a guarded `ALTER TABLE` migration. The migration does not drop or recreate existing student, expense, goal, allocation, or challenge records.

## Phase 1 – Sir's requested changes
- Added the `income` table with allowance/unexpected types, source and received date. The balance formula includes this month's allowance, unexpected money, previous-month positive carry-over, expenses and savings contributions.
- Dashboard balance breakdown shows allowance + extra income + carry-over − expenses − contributions.
- Added unexpected-money capture and deletion, separate dashboard card and green positive transaction entries. Allowance editing and unexpected money are grouped under one Money In section; profile no longer edits allowance.
- Added active desktop navigation, `aria-current="page"`, module-aligned labels and fixed mobile tabs.
- Registration and profile password change use 8-character minimum, letter+number server checks, helper text and show/hide control. Invalid submissions report a specific validation message.

## Phase 2 – Personal planning
- Added student settings for living situation, city type, user-entered daily-spend reference, allowance day, weekend reserve percentage and round-up goal. No external or fabricated cost-of-living data is used.
- Added commitments with monthly / per-semester / one-time frequency, due date, paid status and a Mark as paid action. Marking paid creates one expense and marks the commitment paid so it is not deducted twice.
- The OOP `CommitmentSplitter` calculates unpaid commitment deductions and the daily safe-spend estimate. Negative free money produces a warning. Percentage allocation controls remain for the savings/emergency split.

## Phase 3 – correctness and reporting
- Safe daily limit uses both 7-day and 30-day recorded spending pace and the unpaid essentials/commitments reserve. A month-end guard caps the daily amount at the smaller of the allowance-cycle envelope and a 30-day envelope, preventing a one-day calendar remainder from making the daily limit jump dramatically.
- `Allowance`, `SpendingAnalyzer`, `SavingsGoal`, `SavingsOptimizer`, `RiskSimulator` and `RecommendationEngine` are used by the application; polymorphic risk recommendations use a `unique_ptr` base interface.
- Savings contributions are checked against available balance and reduce that balance. Challenge daily logs are unique per challenge/day.
- CSV transaction export, edit links, delete confirmation, future-date labels and date validation are included.

## Phase 4 – module tools
- Module 1 tools: rollover-style Today's Wallet estimate based on yesterday's recorded spend, seven-day green/yellow/red calendar, streak display, allowance-day countdown, user-entered living-cost reference, Quick Add parser with keyword categories, weekend-fund estimate, Rent and Exam fees categories, commitments splitter.
- Module 2 tools: Worth it / Meh / Regret field, category regret-rate insight, auto priority suggestion from keywords, priority totals, subscription renewal alerts, recorded-entry Spending DNA label and monthly Money Wrapped recap.
- Module 3 tools: safe-limit time-cost tag, shock scenario (simulation only), 24/48-hour wishlist lock and skip counter, essentials-first Broke Mode.
- Module 4 tools: importance/deadline-weighted suggested goal split, completion-date estimate from recorded contribution pace, round-up savings to a selected goal, Friends Owe Me ledger that becomes unexpected income only when marked repaid, and record-based milestone badges.

## Build and run (Windows / Visual Studio Developer Command Prompt)

```bat
cd /d "C:\path\to\BudgetBuddy"
set VCPKG_ROOT=C:\vcpkg
cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE=C:\vcpkg\scripts\buildsystems\vcpkg.cmake -DVCPKG_TARGET_TRIPLET=x64-windows
cmake --build build --config Release
.\build\Release\BudgetBuddy.exe
```

Open `http://127.0.0.1:8080` and keep the server terminal open. Back up `budgetbuddy.db` before the first upgraded run.

## Verification performed for this package
- C++17 syntax check of `main.cpp` and `finance.cpp` passed using a minimal local httplib interface stub (the actual cpp-httplib package was not installed in the build environment).
- Finance model tests passed after the month-end safe-limit change.
- HTTP request handling is configured with a single worker to serialize access to the app's shared SQLite connection and legacy in-memory session state. This is a defensive mitigation; it is not a substitute for reproducing and verifying the Windows crash on the target machine.
- `finance_test.cpp` compiled and passed.
- Linked a local smoke-test executable against system SQLite/OpenSSL and verified that starting the app against a legacy database preserved the existing student row while creating the new tables and adding the `regret` column.
- A full production CMake build and browser end-to-end test still need to be run on the target Windows machine with the project's vcpkg dependencies installed. Do not treat the local stub smoke test as a replacement for that runtime check.

## Important behavior notes
- Quick Add is a deterministic keyword parser, not an AI service. Review categories after parsing.
- Living-cost reference is the user's own assumption; the application does not invent city pricing.
- Simulation and forecast values are estimates from recorded entries, not bank feeds or guaranteed predictions.
- Auto-split produces a suggested affordable allocation; it does not silently transfer or contribute money. Contributions remain an explicit user action.
- Wishlist decisions and badges depend on saved records. A wish marked “Still want it” can only be cleared after its lock period expires.
