#include "finance.hpp"
#include <sstream>
#include <cctype>
#include <regex>
#include <iomanip>
#include <sstream>

namespace budgetbuddy {
Allowance::Allowance() : amount_(0) {}
Allowance::Allowance(double amount) : amount_(0) { setAmount(amount); }
Allowance::Allowance(double amount, const std::string&) : Allowance(amount) {}
void Allowance::setAmount(double amount) { if (!std::isfinite(amount) || amount < 0) throw std::invalid_argument("Allowance must be non-negative"); amount_ = amount; }
Expense::Expense() : amount_(0) {}
Expense::Expense(std::string title, double amount) : Expense(std::move(title), "Other", amount) {}
Expense::Expense(std::string title, std::string category, double amount) : title_(std::move(title)), category_(std::move(category)), amount_(amount) { if (!std::isfinite(amount) || amount < 0) throw std::invalid_argument("Expense must be non-negative"); }
bool Expense::operator<(const Expense& other) const noexcept { return amount_ < other.amount_; }
Expense Expense::operator+(const Expense& other) const { return Expense("Combined expenses", "Combined", amount_ + other.amount_); }
FinancialReport::~FinancialReport() = default;
BudgetManager::BudgetManager() : allowance_() {}
BudgetManager::BudgetManager(Allowance allowance) : allowance_(std::move(allowance)) {}
void BudgetManager::addExpense(const Expense& expense) { expenses_.push_back(expense); }
double BudgetManager::totalExpenses() const { return std::accumulate(expenses_.begin(), expenses_.end(), 0.0, [](double sum, const Expense& e){ return sum + e.amount(); }); }
double BudgetManager::remaining() const { return allowance_.amount() - totalExpenses(); }
std::string BudgetManager::generate() const { std::ostringstream out; out << "Remaining budget: ₹" << std::fixed << std::setprecision(2) << remaining(); return out.str(); }
SpendingAnalyzer::SpendingAnalyzer(std::vector<Expense> expenses) : expenses_(std::move(expenses)) {}
std::vector<Expense> SpendingAnalyzer::highestFirst() const { auto copy = expenses_; std::sort(copy.begin(), copy.end(), [](const Expense& a,const Expense& b){ return b < a; }); return copy; }
std::string SpendingAnalyzer::generate() const { std::ostringstream out; out << expenses_.size() << " expense records analyzed"; return out.str(); }
RecommendationEngine::~RecommendationEngine() = default;
std::string RiskSimulator::recommend(double balance, double dailyAverage) const { if (balance < 0) return "Over budget: pause optional spending."; if (dailyAverage > 0 && balance / dailyAverage < 3) return "High risk: protect essentials and reduce optional spending."; return "Keep tracking and protect essential costs."; }
SavingsGoal::SavingsGoal(std::string title, double target, double saved) : title_(std::move(title)), target_(target), saved_(saved) { if (target <= 0 || saved < 0) throw std::invalid_argument("Goal target must be positive and savings non-negative"); saved_ = std::min(saved_, target_); }
double SavingsGoal::remaining() const noexcept { return std::max(0.0, target_ - saved_); }
double SavingsGoal::progressPercent() const noexcept { return target_ > 0 ? saved_ / target_ * 100.0 : 0.0; }
void SavingsGoal::contribute(double amount) { if (!std::isfinite(amount) || amount <= 0) throw std::invalid_argument("Contribution must be positive"); saved_ = std::min(target_, saved_ + amount); }
double SavingsOptimizer::weeklyContribution(double target, double saved, int daysRemaining) const { if (target < 0 || saved < 0) throw std::invalid_argument("Amounts must be non-negative"); return std::max(0.0, target - saved) / (std::max(1, daysRemaining) / 7.0); }
double SavingsOptimizer::affordableContribution(double availableBalance, double essentialReserve, double proposed) const { if (proposed < 0) throw std::invalid_argument("Contribution must be non-negative"); return std::min(proposed, std::max(0.0, availableBalance - essentialReserve)); }
} // namespace budgetbuddy


namespace budgetbuddy {
double CommitmentSplitter::freeMoney(double income,const std::vector<Commitment>& items) const { double left=income; for(const auto& x:items) if(!x.paid) left-=std::max(0.0,x.amount); return left; }
double CommitmentSplitter::dailySafeSpend(double income,const std::vector<Commitment>& items,double savingsPct,double emergencyPct,int daysLeft) const { double free=freeMoney(income,items); free-=std::max(0.0,income)*std::max(0.0,std::min(100.0,savingsPct))/100.0; free-=std::max(0.0,income)*std::max(0.0,std::min(100.0,emergencyPct))/100.0; return std::max(0.0,free)/std::max(1,daysLeft); }
std::vector<Expense> SmartExpenseParser::parse(const std::string& text) const { std::vector<Expense> out; std::stringstream ss(text); std::string item; std::regex pattern(R"(^\s*(.*?)\s+([0-9]+(?:\.[0-9]+)?)\s*$)"); while(std::getline(ss,item,',')){ std::smatch m; if(!std::regex_match(item,m,pattern)) continue; try { double amount=std::stod(m[2].str()); if(amount<=0||!std::isfinite(amount)) continue; std::string name=m[1].str(),low=name; std::transform(low.begin(),low.end(),low.begin(),[](unsigned char c){return (char)std::tolower(c);}); std::string cat="Other"; if(low.find("chai")!=std::string::npos||low.find("lunch")!=std::string::npos||low.find("food")!=std::string::npos||low.find("coffee")!=std::string::npos)cat="Food"; else if(low.find("auto")!=std::string::npos||low.find("bus")!=std::string::npos||low.find("train")!=std::string::npos)cat="Transport"; else if(low.find("rent")!=std::string::npos)cat="Rent"; else if(low.find("exam")!=std::string::npos||low.find("book")!=std::string::npos)cat="Education"; out.emplace_back(name.empty()?"Quick add":name,cat,amount); } catch(...){} } return out; }
std::vector<double> GoalAllocationOptimizer::allocate(double available,const std::vector<double>& needs,const std::vector<int>& importance,const std::vector<int>& days) const { std::vector<double> out(needs.size(),0); double weights=0; for(size_t i=0;i<needs.size();++i) weights+=std::max(1,importance[i])*(1.0+1.0/std::max(1,days[i])); if(weights<=0)return out; for(size_t i=0;i<needs.size();++i){double w=std::max(1,importance[i])*(1.0+1.0/std::max(1,days[i]));out[i]=std::min(std::max(0.0,needs[i]),std::max(0.0,available)*w/weights);} return out; }
} // namespace budgetbuddy
