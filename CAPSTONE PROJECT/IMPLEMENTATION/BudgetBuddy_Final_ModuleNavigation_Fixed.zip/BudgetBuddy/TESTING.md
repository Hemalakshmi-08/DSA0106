# BudgetBuddy test checklist

Use the manual functional test table in `README.md`. This file is provided so test results can be recorded during the capstone demo.

| Test area | Result | Notes |
|---|---|---|
| Registration validation | Not run | |
| Password hash / login | Not run | |
| Student data isolation | Not run | |
| Allowance update / shock adjustment | Not run | |
| 100% allocation validation | Not run | |
| Add / delete / filter expenses | Not run | |
| Repeated small-spend detection | Not run | |
| Purchase risk simulation | Not run | |
| Multiple goals and contributions | Not run | |
| Challenge progress | Not run | |
| Restart and persistent database | Not run | |
