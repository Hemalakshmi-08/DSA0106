#pragma once
#include <algorithm>
#include <cmath>
#include <memory>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

namespace budgetbuddy {

class Allowance {
    double amount_;
public:
    Allowance();
    explicit Allowance(double amount);
    Allowance(double amount, const std::string& label);
    double amount() const noexcept { return amount_; }
    void setAmount(double amount);
};

class Expense {
    std::string title_, category_;
    double amount_;
public:
    Expense();
    Expense(std::string title, double amount);
    Expense(std::string title, std::string category, double amount);
    double amount() const noexcept { return amount_; }
    const std::string& title() const noexcept { return title_; }
    const std::string& category() const noexcept { return category_; }
    bool operator<(const Expense& other) const noexcept;
    Expense operator+(const Expense& other) const;
};

class FinancialReport {
public:
    virtual ~FinancialReport();
    virtual std::string generate() const = 0;
};

class BudgetManager final : public FinancialReport {
    Allowance allowance_;
    std::vector<Expense> expenses_;
public:
    BudgetManager();
    explicit BudgetManager(Allowance allowance);
    void addExpense(const Expense& expense);
    double totalExpenses() const;
    double remaining() const;
    std::string generate() const override;
};

class SpendingAnalyzer final : public FinancialReport {
    std::vector<Expense> expenses_;
public:
    explicit SpendingAnalyzer(std::vector<Expense> expenses);
    std::vector<Expense> highestFirst() const;
    std::string generate() const override;
};

class RecommendationEngine {
public:
    virtual ~RecommendationEngine();
    virtual std::string recommend(double balance, double dailyAverage) const = 0;
};

class RiskSimulator final : public RecommendationEngine {
public:
    std::string recommend(double balance, double dailyAverage) const override;
};

class SavingsGoal {
    std::string title_;
    double target_, saved_;
public:
    SavingsGoal(std::string title, double target, double saved = 0);
    double remaining() const noexcept;
    double progressPercent() const noexcept;
    void contribute(double amount);
};

class SavingsOptimizer {
public:
    double weeklyContribution(double target, double saved, int daysRemaining) const;
    double affordableContribution(double availableBalance, double essentialReserve, double proposed) const;
};



struct Commitment { std::string name; double amount; bool paid; };
class CommitmentSplitter {
public:
    double freeMoney(double income, const std::vector<Commitment>& items) const;
    double dailySafeSpend(double income, const std::vector<Commitment>& items, double savingsPct, double emergencyPct, int daysLeft) const;
};
class SmartExpenseParser {
public:
    std::vector<Expense> parse(const std::string& text) const;
};
class GoalAllocationOptimizer {
public:
    std::vector<double> allocate(double available, const std::vector<double>& needs, const std::vector<int>& importance, const std::vector<int>& daysRemaining) const;
};

} // namespace budgetbuddy
