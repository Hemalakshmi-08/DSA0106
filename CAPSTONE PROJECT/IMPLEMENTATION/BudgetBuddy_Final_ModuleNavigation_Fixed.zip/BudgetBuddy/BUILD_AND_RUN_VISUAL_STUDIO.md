# BudgetBuddy - Visual Studio 2026 build

1. Open this `BudgetBuddy` folder in Visual Studio 2026 (the folder containing `CMakeLists.txt`).
2. Open View > Terminal. Use Visual Studio 2026 Developer PowerShell.
3. Set the vcpkg path if needed: `$env:VCPKG_ROOT="C:\vcpkg"`.
4. Run `powershell -ExecutionPolicy Bypass -File .\BUILD_BUDGETBUDDY.ps1`.
5. After a successful build, run `.\build\Release\BudgetBuddy.exe`.
6. Open `http://127.0.0.1:8080` and keep the terminal open.

The build script uses classic vcpkg mode. It installs cpp-httplib, sqlite3 and openssl into the x64-windows triplet and disables manifest mode during CMake configuration. This avoids requiring the vcpkg directory to be a Git checkout or requiring a `builtin-baseline` in `vcpkg.json`.

If dependency installation fails, check that `C:\vcpkg\vcpkg.exe` exists and that the computer can access the package registry. This script does not delete your source files or database; it only removes the generated `build` directory before configuring.
