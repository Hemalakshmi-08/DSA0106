$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectDir

Write-Host '=== BudgetBuddy: Visual Studio 2026 build (classic vcpkg mode) ===' -ForegroundColor Cyan

$VcpkgRoot = if ($env:VCPKG_ROOT) { $env:VCPKG_ROOT } else { 'C:\vcpkg' }
$VcpkgExe = Join-Path $VcpkgRoot 'vcpkg.exe'
$VcpkgToolchain = Join-Path $VcpkgRoot 'scripts\buildsystems\vcpkg.cmake'

if (-not (Test-Path $VcpkgExe)) { throw "vcpkg.exe not found at $VcpkgExe. Check VCPKG_ROOT." }
if (-not (Test-Path $VcpkgToolchain)) { throw "vcpkg toolchain not found at $VcpkgToolchain." }
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) { throw 'CMake is not on PATH. Run from Visual Studio 2026 Developer PowerShell.' }

# This project uses classic vcpkg mode so an installed vcpkg folder does not
# need to be a Git checkout and no builtin-baseline is required.
Write-Host 'Installing required libraries with classic vcpkg mode...' -ForegroundColor Cyan
& $VcpkgExe install --classic --triplet=x64-windows cpp-httplib sqlite3 openssl
if ($LASTEXITCODE -ne 0) { throw "vcpkg dependency installation failed (exit code $LASTEXITCODE). Check vcpkg output and network access." }

# Avoid stale generator/toolset settings from previous attempts.
$BuildDir = Join-Path $ProjectDir 'build'
if (Test-Path $BuildDir) {
    Write-Host 'Removing old generated build directory (source and database are untouched)...' -ForegroundColor Yellow
    Remove-Item $BuildDir -Recurse -Force
}

$Generator = 'Visual Studio 18 2026'
Write-Host "Configuring with $Generator ..." -ForegroundColor Cyan
& cmake -G $Generator -A x64 -S . -B build `
    "-DCMAKE_TOOLCHAIN_FILE=$VcpkgToolchain" `
    '-DVCPKG_TARGET_TRIPLET=x64-windows' `
    '-DVCPKG_MANIFEST_MODE=OFF'
if ($LASTEXITCODE -ne 0) { throw "CMake configuration failed (exit code $LASTEXITCODE). Confirm the VS 2026 C++ workload is installed." }

Write-Host 'Building Release...' -ForegroundColor Cyan
& cmake --build build --config Release
if ($LASTEXITCODE -ne 0) { throw "Build failed (exit code $LASTEXITCODE)." }

Write-Host 'Running model tests...' -ForegroundColor Cyan
& ctest --test-dir build -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw "One or more tests failed (exit code $LASTEXITCODE)." }

Write-Host ''
Write-Host 'BUILD SUCCEEDED. Start BudgetBuddy with:' -ForegroundColor Green
Write-Host '.\build\Release\BudgetBuddy.exe' -ForegroundColor White
Write-Host 'Then open http://127.0.0.1:8080 and keep the terminal open.' -ForegroundColor Green
