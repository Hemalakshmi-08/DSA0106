@echo off
setlocal
cd /d "%~dp0"
title BudgetBuddy Build
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_BUDGETBUDDY.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Read the error above and share it for troubleshooting.
  pause
  exit /b 1
)
echo.
pause
endlocal
