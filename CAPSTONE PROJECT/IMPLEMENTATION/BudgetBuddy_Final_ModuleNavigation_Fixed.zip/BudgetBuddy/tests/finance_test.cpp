#include "finance.hpp"
#include <cassert>
#include <cmath>
#include <stdexcept>

int main() {
    using namespace budgetbuddy;
    BudgetManager budget(Allowance(1000));
    budget.addExpense(Expense("Lunch", "Food", 100));
    budget.addExpense(Expense("Bus", "Transport", 50));
    assert(std::abs(budget.totalExpenses() - 150.0) < 0.001);
    assert(std::abs(budget.remaining() - 850.0) < 0.001);

    Expense a("Snack", "Food", 30), b("Coffee", "Food", 20);
    Expense combined = a + b; // operator overloading
    assert(std::abs(combined.amount() - 50.0) < 0.001);

    SavingsGoal goal("Laptop", 10000, 2500);
    goal.contribute(500);
    assert(std::abs(goal.progressPercent() - 30.0) < 0.001);
    goal.contribute(99999);
    assert(std::abs(goal.progressPercent() - 100.0) < 0.001); // capped at target

    RiskSimulator risk;
    assert(!risk.recommend(-10, 20).empty());
    SavingsOptimizer optimizer;
    assert(std::abs(optimizer.weeklyContribution(1000, 0, 14) - 500.0) < 0.001);
    assert(std::abs(optimizer.affordableContribution(300, 200, 500) - 100.0) < 0.001);

    bool rejected = false;
    try { Allowance bad(-1); } catch (const std::invalid_argument&) { rejected = true; }
    assert(rejected);
    return 0;
}
